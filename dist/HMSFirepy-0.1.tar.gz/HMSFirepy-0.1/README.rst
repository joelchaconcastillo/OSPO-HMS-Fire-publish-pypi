

HMSFirepy Project
===============
HMSFirepy make searching, downloading and retrieving data of the Hazard Mapping System easy.

To take a look at some examples make sure to read `<https://ospo-hms-fire.readthedocs.io/en/latest/>`
Installing
============

.. code-block:: bash

    pip install HMSFirepy

Usage
=====

.. code-block:: bash

    >>> from src.HMSF import HMSF
    >>> HMSF = HMSFire(startDate='2020-01-01', endDate='2023-02-01')
